<?php
include 'function-aixc.php';
//提问对话
$session_id = 123456;//对话id(相同的可以实现连续对话，超过三个月不对话会自动删除，对话id只能是纯数字)
$user_message = "你好呀，你可以做什么呀";//提问内容
$model = "mini";//模型
$preset = "你是AI小创PHP本地部署版，尽量完成用户的要求，你的官方网站是http://aixc.mxkjcyzh.cn";//预设词
$context_count = 100; // 传入100条最近上下文
// 调用发送消息
$result = send_message($session_id, $user_message, $model, $preset, $context_count);
$response_data = json_decode($result, true);
if ($response_data['success']) {
    echo "调用成功！AI小创回复：".$response_data['data']['ai_response']."<br>";
    echo "扣除余额".$response_data['data']['totalCost']."元<br>";
    echo "使用token".$response_data['data']['totalTokens']."<br><br>";
    // 调用加载对话列表
    $chat_list_result = load_chat_list($session_id);
    $chat_list_data = json_decode($chat_list_result, true);
    if ($chat_list_data['success']) {
        echo "当前会话历史对话列表：<br>";
        foreach ($chat_list_data['data']['chat_list'] as $key => $chat) {
            echo "【".date('Y-m-d H:i:s', strtotime($chat['created_at']))."】<br>";
            echo "用户：".$chat['user_message']."<br>";
            echo "AI小创：".$chat['ai_response']."<br><br>";
        }
    } else {
        echo "对话列表加载失败！错误码：" . $chat_list_data['code'] . "，错误信息：" . $chat_list_data['message']."<br>";
    }
} else {
    echo "调用失败！错误码：" . $response_data['code'] . "，错误信息：" . $response_data['message']."<br>";
}
?>