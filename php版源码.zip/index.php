<?php
function send_message($session_id, $user_message, $model, $preset, $context_count) {
    $token = "your_token_here";//AI小创token
    $api_url = "http://openapi.mxkjcyzh.cn/openapi/aixc.php";
    $servername = "localhost";//数据库地址
    $username = "your_username";//数据库用户名
    $password = "your_password";//数据库密码
    $dbname = "your_database";//数据库名
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        return json_encode(['success' => false, 'code' => 500, 'message' => '数据库连接失败: ' . $conn->connect_error]);
    }
    $sql = "CREATE TABLE IF NOT EXISTS chat_sessions (
        id INT PRIMARY KEY,
        updated_at DATETIME,
        is_processing TINYINT(1) DEFAULT 0
    ) ENGINE=InnoDB;";
    $conn->query($sql);
    $sql = "CREATE TABLE IF NOT EXISTS chat_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        session_id INT,
        user_message TEXT,
        ai_response TEXT,
        model VARCHAR(20),
        preset_words TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (session_id) REFERENCES chat_sessions(id)
    ) ENGINE=InnoDB;";
    $conn->query($sql);
    $conn->begin_transaction();
    try {
        $sql = "SELECT id, updated_at, is_processing FROM chat_sessions WHERE id = ? FOR UPDATE";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $session_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $session = $result->fetch_assoc();
        if ($session && $session['is_processing'] == 1) {
            $conn->commit();
            return json_encode(['success' => false, 'code' => 400, 'message' => '正在处理中，请稍候...']);
        }
        if (!$session || (time() - strtotime($session['updated_at']) > 15*24*3600)) {
            if ($session) {
                $sql = "DELETE FROM chat_sessions WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $session_id);
                $stmt->execute();
            }
            $sql = "INSERT INTO chat_sessions (id, updated_at, is_processing) VALUES (?, NOW(), 0)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $session_id);
            $stmt->execute();
        }
        $sql = "UPDATE chat_sessions SET is_processing = 1, updated_at = NOW() WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $session_id);
        $stmt->execute();
        $sql = "SELECT user_message, ai_response FROM chat_records WHERE session_id = ? ORDER BY id DESC LIMIT ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $session_id, $context_count);
        $stmt->execute();
        $result = $stmt->get_result();
        $history_rows = [];
        while ($row = $result->fetch_assoc()) {
            $history_rows[] = $row;
        }
        $history_rows = array_reverse($history_rows);
        $chat_history = [];
        foreach ($history_rows as $row) {
            $chat_history[] = ["role" => "user", "content" => $row["user_message"]];
            $chat_history[] = ["role" => "ai", "content" => $row["ai_response"]];
        }
        $chat_history[] = ["role" => "user", "content" => $user_message];
        $data = [
            "token" => $token,
            "chat_records" => $chat_history,
            "model" => $model,
            "ysc" => $preset
        ];
        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($http_code != 200) {
            $conn->rollback();
            return json_encode(['success' => false, 'code' => $http_code, 'message' => 'API请求失败，HTTP状态码: ' . $http_code]);
        }
        $api_data = json_decode($response, true);
        if (empty($api_data) || !isset($api_data['code'])) {
            $conn->rollback();
            return json_encode(['success' => false, 'code' => 500, 'message' => 'API响应格式错误']);
        }
        if ($api_data['code'] == 200) {
            $ai_response = $api_data["data"]["reply"];
            $totalTokens = $api_data["data"]["totalTokens"];
            $totalCost = $api_data["data"]["totalCost"];
            $sql = "INSERT INTO chat_records (session_id, user_message, ai_response, model, preset_words) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("issss", $session_id, $user_message, $ai_response, $model, $preset);
            $stmt->execute();
            $sql = "UPDATE chat_sessions SET is_processing = 0, updated_at = NOW() WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $session_id);
            $stmt->execute();
            $conn->commit();
            return json_encode([
                'success' => true,
                'code' => 200,
                'message' => '处理成功',
                'data' => ['ai_response' => $ai_response, 'totalTokens' => $totalTokens, 'totalCost' => $totalCost, 'session_id' => $session_id]
            ]);
        } else {
            $conn->rollback();
            return json_encode([
                'success' => false,
                'code' => $api_data['code'],
                'message' => '处理失败: ' . ($api_data['msg'] ?? '未知错误')
            ]);
        }
    } catch (Exception $e) {
        $conn->rollback();
        return json_encode(['success' => false, 'code' => 500, 'message' => '系统异常: ' . $e->getMessage()]);
    }
}

$session_id = 1234567890;//对话id
$user_message = "你好，你是谁";//提问内容
$model = "4.0-Pro";//模型
$preset = "你是AI小创PHP本地部署版，尽量完成用户的要求";//预设词
$context_count = 100; // 传入100条最近上下文
$result = send_message($session_id, $user_message, $model, $preset, $context_count);
$response_data = json_decode($result, true);
if ($response_data['success']) {
    echo "调用成功！AI回复：".$response_data['data']['ai_response'];
    echo "扣除余额".$response_data['data']['totalCost']."元";
    echo "使用token".$response_data['data']['totalTokens'];
} else {
    echo "调用失败！错误码：" . $response_data['code'] . "，错误信息：" . $response_data['message'];
}