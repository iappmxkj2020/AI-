<?php
header('Content-Type:text/html;charset=utf-8');
error_reporting(0);
ini_set('display_errors', 0);
//官方网站https://aixc.mxkjcyzh.cn
function send_message($session_id, $user_message, $model, $preset, $context_count) {
    clean_expired_files();
    $token = "token_here";//AI小创token(开启联网搜索和深度思考需要，可前往官方网站申请)
    $dir = 'sjk';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $file_path = $dir . '/' . $session_id . '.json';
    $session_data = [
        'is_processing' => 0,
        'updated_at' => date('Y-m-d H:i:s'),
        'messages' => []
    ];
    if (file_exists($file_path)) {
        $json_content = file_get_contents($file_path);
        $decoded_data = json_decode($json_content, true);
        if (is_array($decoded_data)) {
            $session_data = $decoded_data;
        }
    }
    if ($session_data['is_processing'] == 1) {
        return json_encode(['success' => false, 'code' => 400, 'message' => '正在处理中，请稍候...']);
    }
    $session_data['is_processing'] = 1;
    $session_data['updated_at'] = date('Y-m-d H:i:s');
    $encrypted_session = json_encode($session_data);
    if ($encrypted_session === false) {
        return json_encode(['success' => false, 'code' => 500, 'message' => '文件加密失败']);
    }
    file_put_contents($file_path, $encrypted_session);
    $messages = $session_data['messages'];
    $recent_records = array_slice($messages, -$context_count);
    $chat_history = [];
    foreach ($recent_records as $record) {
        $chat_history[] = ["role" => "user", "content" => $record["user_message"]];
        $chat_history[] = ["role" => "assistant", "content" => $record["ai_response"]];
    }
    $chat_history[] = ["role" => "user", "content" => $user_message];
    $data = [
        "token" => $token,
        "messages" => $chat_history,
        "model" => $model,
        "ysc" => $preset
    ];
    $ch = curl_init("https://openapi.mxkjcyzh.cn/openapi/aixc.php");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($http_code != 200) {
        $session_data['is_processing'] = 0;
        $session_data['updated_at'] = date('Y-m-d H:i:s');
        $encrypted_session = json_encode($session_data);
        file_put_contents($file_path, $encrypted_session);
        return json_encode(['success' => false, 'code' => $http_code, 'message' => 'API请求失败，HTTP状态码: ' . $http_code]);
    }
    $api_data = json_decode($response, true);
    if (empty($api_data) || !isset($api_data['code'])) {
        $session_data['is_processing'] = 0;
        $session_data['updated_at'] = date('Y-m-d H:i:s');
        $encrypted_session = json_encode($session_data);
        file_put_contents($file_path, $encrypted_session);
        return json_encode(['success' => false, 'code' => 500, 'message' => 'API响应格式错误']);
    }
    if ($api_data['code'] == 200) {
        $ai_response = $api_data["data"]["reply"];
        $totalCost = $api_data["data"]["totalCost"];
        $totalTokens = $api_data["data"]["totalTokens"];
        $new_record = [
            'user_message' => $user_message,
            'ai_response' => $ai_response,
            'model' => $model,
            'preset_words' => $preset,
            'created_at' => date('Y-m-d H:i:s')
        ];
        $session_data['messages'][] = $new_record;
        $session_data['is_processing'] = 0;
        $session_data['updated_at'] = date('Y-m-d H:i:s');
        $encrypted_session = json_encode($session_data);
        file_put_contents($file_path, $encrypted_session);
        return json_encode([
            'success' => true,
            'code' => 200,
            'message' => '处理成功',
            'data' => ['ai_response' => $ai_response, 'totalCost' => $totalCost, 'totalTokens' => $totalTokens, 'session_id' => $session_id]
        ]);
    } else {
        $session_data['is_processing'] = 0;
        $session_data['updated_at'] = date('Y-m-d H:i:s');
        $encrypted_session = json_encode($session_data);
        file_put_contents($file_path, $encrypted_session);
        return json_encode([
            'success' => false,
            'code' => $api_data['code'],
            'message' => '处理失败: ' . ($api_data['msg'] ?? '未知错误')
        ]);
    }
}
function decode_unicode($json_content) {
    return preg_replace_callback('/\\\\u([0-9a-fA-F]{4})/', function($matches) {
        return mb_convert_encoding(pack('H*', $matches[1]), 'UTF-8', 'UTF-16BE');
    }, $json_content);
}
function load_chat_list($session_id) {
    $dir = 'sjk';
    $file_path = $dir . '/' . $session_id . '.json';
    if (!file_exists($file_path)) {
        return json_encode([
            'success' => true,
            'code' => 200,
            'message' => '加载成功',
            'data' => ['chat_list' => [], 'session_id' => $session_id]
        ]);
    }
    $json_content = file_get_contents($file_path);
    $decoded_json = decode_unicode($json_content); 
    $session_data = json_decode($decoded_json, true) ?: [];
    $chat_list = $session_data['messages'] ?? [];
    return json_encode([
        'success' => true,
        'code' => 200,
        'message' => '加载成功',
        'data' => ['chat_list' => $chat_list, 'session_id' => $session_id]
    ]);
}
function clean_expired_files() {
    $dir = 'sjk';
    $expire_days = 90;
    if (!is_dir($dir)) {
        return;
    }
    $now = time();
    $files = scandir($dir);
    foreach ($files as $file) {
        $file_path = $dir . '/' . $file;
        if (is_dir($file_path) || pathinfo($file, PATHINFO_EXTENSION) !== 'json') {
            continue;
        }
        $file_mtime = filemtime($file_path);
        if ($now - $file_mtime > $expire_days * 86400) {
            @unlink($file_path);
        }
    }
}
?>